enum ActionUserListType { followers, followings, repos, star, forks }
enum ActionUserListState { initial, loading, loaded, error }
enum CurrentUserRepoListState { initial, loading, loaded, error }
enum CurrentUserState { initial, loading, loaded, error }
