import 'package:fluro/fluro.dart';

class Application {
  static late final FluroRouter router;
}
