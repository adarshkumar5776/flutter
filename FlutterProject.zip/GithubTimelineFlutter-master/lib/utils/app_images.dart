class AppImages {
  static const ic_fork = "assets/images/fork.png";
  static const github_logo = "assets/images/github--v1.png";
}
